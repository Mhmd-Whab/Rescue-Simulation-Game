package controller;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

import exceptions.BuildingAlreadyCollapsedException;
import exceptions.CannotTreatException;
import exceptions.IncompatibleTargetException;
import exceptions.SimulationException;
import exceptions.UnitException;
import model.disasters.Collapse;
import model.disasters.Fire;
import model.disasters.GasLeak;
import model.disasters.Infection;
import model.disasters.Injury;
import model.events.SOSListener;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import model.people.CitizenState;
import model.units.Ambulance;
import model.units.DiseaseControlUnit;
import model.units.Evacuator;
import model.units.FireTruck;
import model.units.GasControlUnit;
import model.units.Unit;
import model.units.UnitState;
import simulation.Rescuable;
import simulation.Simulator;
import view.RescueSimulation;

public class CommandCenter implements SOSListener, ActionListener {

	private Simulator engine;
	private ArrayList<ResidentialBuilding> visibleBuildings;
	private ArrayList<Citizen> visibleCitizens;
	private RescueSimulation rescueSimulation;
	private ArrayList<JButton> unitsbuttons;
	private int i=0;
	private Unit LastUnit ;
	private ArrayList<Unit> emergencyUnits;

	public CommandCenter() throws Exception {
		engine = new Simulator(this);
		visibleBuildings = new ArrayList<ResidentialBuilding>();
		visibleCitizens = new ArrayList<Citizen>();
		emergencyUnits = engine.getEmergencyUnits();
		unitsbuttons= new ArrayList<JButton>();
		rescueSimulation = new RescueSimulation(this);
		for(int i=0;i<engine.getEmergencyUnits().size();i++) {
			JButton unitb = new JButton("");
			unitsbuttons.add(unitb);
			unitb.addActionListener(this);
			
		}
		rescueSimulation.AddUnits(unitsbuttons,engine.getEmergencyUnits());
		
		rescueSimulation.setVisible(true);
	}

	@Override
	public void receiveSOSCall(Rescuable r) {
		
		if (r instanceof ResidentialBuilding) {
			
			if (!visibleBuildings.contains(r)) {
				visibleBuildings.add((ResidentialBuilding) r);
				rescueSimulation.AddBuildings(visibleBuildings,this);
				String s = "***Disaster affected a Building*** "+"\n";
				if(r.getDisaster() instanceof Collapse) {
					s+= "-Building Disaster : Collapse"+"\n";
				}if(r.getDisaster() instanceof Fire) {
					s+= "-Building Disaster : Fire"+"\n";
				}if(r.getDisaster() instanceof GasLeak) {
					s+= "-Building Disaster : Gas Leak "+"\n";
				}
				s+="-Location :"+"("+r.getLocation().getX()+","+r.getLocation().getY()+")"+"\n";
				rescueSimulation.getLog().setText(rescueSimulation.getLog().getText()+s);
			}else {
				String s = "** An additional Disaster affected a Building **"+"\n";
				if(r.getDisaster() instanceof Collapse) {
					s+= "-New Building Disaster : Collapse"+"\n";
				}if(r.getDisaster() instanceof Fire) {
					s+= "-New Building Disaster : Fire"+"\n";
				}if(r.getDisaster() instanceof GasLeak) {
					s+= "-New Building Disaster : Gas Leak "+"\n";
				}
				s+="-Location :"+"("+r.getLocation().getX()+","+r.getLocation().getY()+")"+"\n";
				rescueSimulation.getLog().setText(rescueSimulation.getLog().getText()+s);

			}
		} else {
			
			if (!visibleCitizens.contains(r))
				visibleCitizens.add((Citizen) r);
			rescueSimulation.AddCitizens(visibleCitizens,this);
			String s = "***Disaster affected a Citizen*** "+"\n";
			s+= "-Name : "+((Citizen)r).getName()+"\n";
			s+= "-Location "+"("+r.getLocation().getX()+","+r.getLocation().getY()+")"+"\n";
			if(r.getDisaster() instanceof Injury) {
				s+= "-Disaster :"+"Injury"+"\n";
			}else {
				s+= "-Disaster :"+"Infection"+"\n";
			}
			rescueSimulation.getLog().setText(rescueSimulation.getLog().getText()+s);
		}

	}public Simulator getEngine() {
		return engine;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton b =(JButton) e.getSource();
		/*if(b == rescueSimulation.getSound()) {

			if(rescueSimulation.getClip().isActive()) {
				rescueSimulation.getClip().stop();
				ImageIcon run = new ImageIcon(this.getClass().getResource("/play-button.png").getFile());
				Image r = run.getImage().getScaledInstance(50, 50, 50);
				run = new ImageIcon(r);
				rescueSimulation.getSound().setIcon(run);
			}
			else {
				rescueSimulation.getClip().start();
				ImageIcon stop = new ImageIcon(this.getClass().getResource("/stop.png").getFile());
				Image st = stop.getImage().getScaledInstance(50, 50, 50);
				stop = new ImageIcon(st);
				rescueSimulation.getSound().setIcon(stop);

			}
		}*/
		if(e.getActionCommand().equals("Next Cycle")) {
			
				try {
					engine.nextCycle();
				} catch (SimulationException e1) {
					if (e1 instanceof BuildingAlreadyCollapsedException ) {
						//TODO 
					}
				}
				if(engine.checkGameOver()) {
					String s = "*** Game Over ***"+"\n";
					s+= "Statistics"+"\n";
					s+="Number of all Citizens :"+rescueSimulation.getNumofCitz()+"\n";
					s+= "Number of Casualties : "+engine.calculateCasualties()+"\n";
					s+= "percentage : "+ (Integer)((rescueSimulation.getNumofCitz()-engine.calculateCasualties())*100)/rescueSimulation.getNumofCitz()+"%";
					JOptionPane.showMessageDialog(null,s);
					rescueSimulation.setVisible(false);
					try {
						rescueSimulation.setVisible(false);
						//scueSimulation.getClip().close();
						CommandCenter cc1 = new CommandCenter();
						//TODO
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				else {
					rescueSimulation.getInformation().setText("*** Units Information ***");
					rescueSimulation.getCitynformation().setText("*** City Information ***");
					String sd= "*** Active Disasters ***"+"\n";
					for(int i=0;i<engine.getExecutedDisasters().size() ;i++) {
						
						if(engine.getExecutedDisasters().get(i) instanceof Collapse) {
							if(engine.getExecutedDisasters().get(i).isActive()){
								sd+= "Type : Collapse"+"\n";
								sd+="Target is Building at Location :"+ "("+engine.getExecutedDisasters().get(i).getTarget().getLocation().getX()+","+engine.getExecutedDisasters().get(i).getTarget().getLocation().getY()+")"+"\n";
								sd+= "------------"+"\n";
							}	
						}
						else if(engine.getExecutedDisasters().get(i) instanceof Fire) {
							if(engine.getExecutedDisasters().get(i).isActive()){
								sd+= "Type : Fire"+"\n";
								sd+="Target is Building at Location :"+ "("+engine.getExecutedDisasters().get(i).getTarget().getLocation().getX()+","+engine.getExecutedDisasters().get(i).getTarget().getLocation().getY()+")"+"\n";
								sd+= "------------"+"\n";
							}	
						}
						else if(engine.getExecutedDisasters().get(i) instanceof GasLeak) {
							if(engine.getExecutedDisasters().get(i).isActive()){
								sd+= "Type : Gas Leak"+"\n";
								sd+="Target is Building at Location :"+ "("+engine.getExecutedDisasters().get(i).getTarget().getLocation().getX()+","+engine.getExecutedDisasters().get(i).getTarget().getLocation().getY()+")"+"\n";
								sd+= "------------"+"\n";
							}	
						}
						else if (engine.getExecutedDisasters().get(i) instanceof Infection) {
							if(engine.getExecutedDisasters().get(i).isActive()){
								sd+= "Type : Infection"+"\n";
								sd+="Target is Citizen at Location :"+ "("+engine.getExecutedDisasters().get(i).getTarget().getLocation().getX()+","+engine.getExecutedDisasters().get(i).getTarget().getLocation().getY()+")"+"\n";
								sd+= "------------"+"\n";
							}
						}
						else if(engine.getExecutedDisasters().get(i) instanceof Injury ) {
							if(engine.getExecutedDisasters().get(i).isActive()){
								sd+= "Type : Injury"+"\n";
								sd+="Target is Citizen at Location :"+ "("+engine.getExecutedDisasters().get(i).getTarget().getLocation().getX()+","+engine.getExecutedDisasters().get(i).getTarget().getLocation().getY()+")"+"\n";
								sd+= "------------"+"\n";
							}	
						}
					}
					rescueSimulation.getActiveDisasters().setText(sd);
					if(this.LastUnit!=null)
						getUnitBurtton(this.LastUnit).setText("");
					this.LastUnit=null;
					//TODO renew the info panel
					rescueSimulation.getCitynformation();
					int lastcasualties = engine.calculateCasualties();
				i=i+1;
				rescueSimulation.getCCycle().setText("Current Cycle : " +i);
				if(lastcasualties!=engine.calculateCasualties())
					rescueSimulation.getCasualties().setText("Number of Casualties : "+engine.calculateCasualties());
				for(int i=0;i<visibleCitizens.size()&&visibleCitizens.get(i)!=null;i++) {
					if(visibleCitizens.get(i).getState()==CitizenState.DECEASED) {
						String s = "*** A Citizen is Deceased ***"+"\n";
						s+= "Name :"+visibleCitizens.get(i).getName()+"\n";
						s+= "Location "+"("+visibleCitizens.get(i).getLocation().getX()+","+visibleCitizens.get(i).getLocation().getY()+")"+"\n";
						ImageIcon CitizenPhoto = new ImageIcon(this.getClass().getResource("/danger.png").getFile());
						Image un = CitizenPhoto.getImage().getScaledInstance(70, 65, 100);
						CitizenPhoto = new ImageIcon(un);
						rescueSimulation.getCitybuttons()[9-visibleCitizens.get(i).getLocation().getY()][visibleCitizens.get(i).getLocation().getX()].setIcon(CitizenPhoto);
						visibleCitizens.get(i).getDisaster().setActive(false);
						visibleCitizens.remove(i);
						rescueSimulation.getLog().setText(rescueSimulation.getLog().getText()+s);
						//TODO change icon
					}
				}
				for(int i=0;i<visibleBuildings.size()&&visibleBuildings.get(i)!=null;i++) {
					ResidentialBuilding rb = visibleBuildings.get(i);
					if(rb.getStructuralIntegrity()==0) {
						String s = "*** A Building is Collapsed ***"+"\n";
						s+= "-Location "+"("+rb.getLocation().getX()+","+rb.getLocation().getY()+")"+"\n";
						for(int j = 1 ;j<visibleBuildings.get(i).getOccupants().size()+1&&visibleBuildings.get(i).getOccupants().get(j-1)!=null;j++) {
							s+= "Citizen "+j+" died in this building :"+"\n";
							s+= "Name :"+visibleBuildings.get(i).getOccupants().get(j-1).getName()+"\n";
							s+= "Location "+"("+visibleBuildings.get(i).getOccupants().get(j-1).getLocation().getX()+","+visibleBuildings.get(i).getOccupants().get(j-1).getLocation().getY()+")"+"\n";
						}
						rescueSimulation.getLog().setText(rescueSimulation.getLog().getText()+s);
						ImageIcon buildingPhoto = new ImageIcon(this.getClass().getResource("/house.png").getFile());
						Image un = buildingPhoto.getImage().getScaledInstance(70, 65, 100);
						buildingPhoto = new ImageIcon(un);
						rescueSimulation.getCitybuttons()[9-rb.getLocation().getY()][rb.getLocation().getX()].setIcon(buildingPhoto);
						visibleBuildings.get(i).getDisaster().setActive(false);
						visibleBuildings.remove(i);
	
					}
				}
			}
		}
		else if (unitsbuttons.contains(b)){
			int indx =  unitsbuttons.indexOf(b);
			Unit hwada = emergencyUnits.get(indx);
			//firstly appear info
			
			String s= "Unit Information"+"\n";
			s+= "ID : "+ hwada.getUnitID()+"\n";
			if(hwada instanceof Ambulance) {
			s+="Type :" +"Ambulance"+ "\n";
			}
			else if (hwada instanceof DiseaseControlUnit) {
				s+="Type :" +"DiseaseControlUnit"+ "\n";
			}
			else if (hwada instanceof Evacuator) {
				s+="Type :" +"Evacuator"+ "\n";
			}
			else if (hwada instanceof FireTruck) {
				s+="Type :" +"FireTruck"+ "\n";
			}
			else if (hwada instanceof GasControlUnit) {
				s+="Type :" +"GasControlUnit"+ "\n";
			}
			s+= "Location"+ "("+hwada.getLocation().getX()+","+hwada.getLocation().getY()+")"+"\n";
			s+= "Steps per Cycle : "+hwada.getStepsPerCycle()+"\n";
			if(hwada.getTarget()!=null) {
				if(hwada.getTarget() instanceof Citizen) {
					s+= "Target is : "+((Citizen)hwada.getTarget()).getName()+"\n";
				}else {
					s+= "Target is : Building"+"\n";
				}
				 s+="Target location :"+"("+hwada.getTarget().getLocation().getX()+","+hwada.getTarget().getLocation().getY()+")"+"\n";
			}
			s+= "State : "+ hwada.getState()+"\n";
			if(hwada instanceof Evacuator) {
				s+= "Number of Passengers :"+((Evacuator)hwada).getPassengers().size()+"\n";
				if(((Evacuator)hwada).getPassengers().size()!=0)
					s+= "Passengers Information :"+"\n";
				for(int i=1 ; i<((Evacuator)hwada).getPassengers().size()+1;i++) {
					Citizen c = ((Evacuator)hwada).getPassengers().get(i);
					s+= "Passenger "+i+"\n";
					s+= "Location "+"("+hwada.getLocation().getX()+","+hwada.getLocation().getY()+")"+"\n";
					s+= "Name :"+c.getName()+"\n";
					s+= "Age :"+c.getAge()+"\n";
					s+= "National ID :"+c.getNationalID()+"\n";
					s+= "HP :"+c.getHp()+"\n";
					s+= "Blood loss :"+c.getBloodLoss()+"\n";
					s+= "Toxicity :"+c.getToxicity()+"\n";
					s+= "State :"+c.getState()+"\n";
					if(c.getDisaster()!=null) {
						if(c.getDisaster() instanceof Injury) {
							s+= "Disaster :"+"Injury"+"\n";
						}else {
							s+= "Disaster :"+"Infection"+"\n";
						}
					}	
				}
			}
			rescueSimulation.getInformation().setText(s);
			if(this.LastUnit==null) {
				this.LastUnit=hwada;
				getUnitBurtton(this.LastUnit).setText("");
			}
			else if(this.LastUnit==hwada) {
				getUnitBurtton(this.LastUnit).setText("");
				this.LastUnit=null;
			}
			else if (this.LastUnit!=hwada) {
				getUnitBurtton(this.LastUnit).setText("");
				getUnitBurtton(hwada).setText("");
				this.LastUnit=hwada;
			}
		}
		else {
			boolean notfound = true;
			rescueSimulation.getInformation().setText("*** Units Information ***");
			for(int i=0;i<10 && notfound ;i++) {
				for(int j=0;j<10&& notfound;j++) {
					if(b==rescueSimulation.getCitybuttons()[i][j]) {
						notfound=false;
						if(rescueSimulation.getCitycontent()[i][j] instanceof Citizen) {
							Citizen c = (Citizen) rescueSimulation.getCitycontent()[i][j];
							if(this.LastUnit!=null) {
								try {
									this.LastUnit.respond(c);
									getUnitBurtton(this.LastUnit).setText("");
									this.LastUnit=null;
									
								} catch (UnitException e1) {
									if(e1 instanceof CannotTreatException) {
										getUnitBurtton(this.LastUnit).setText("");
										this.LastUnit=null;
										JOptionPane.showMessageDialog(null,"Can not treat");
									}
									else if (e1 instanceof IncompatibleTargetException) {
										getUnitBurtton(this.LastUnit).setText("");
										this.LastUnit=null;
										JOptionPane.showMessageDialog(null,"Incompatable Target");
									}
								}
							}	
							rescueSimulation.getCitynformation().setText(c.CitizenInfo());	
							
						}
						else if (rescueSimulation.getCitycontent()[i][j] instanceof ResidentialBuilding) {
							
							ResidentialBuilding rb = (ResidentialBuilding) rescueSimulation.getCitycontent()[i][j];
							if(this.LastUnit!=null) {
								try {
									this.LastUnit.respond(rb);
									getUnitBurtton(this.LastUnit).setText("");
									this.LastUnit=null;
								} catch (UnitException e1) {
									if(e1 instanceof CannotTreatException) {
										getUnitBurtton(this.LastUnit).setText("");
										this.LastUnit=null;
										JOptionPane.showMessageDialog(null,"Can not treat");
									}
									else if (e1 instanceof IncompatibleTargetException) {
										getUnitBurtton(this.LastUnit).setText("");
										this.LastUnit=null;
										JOptionPane.showMessageDialog(null,"Incompatable Target");
									}
								}
							}
							rescueSimulation.getCitynformation().setText(rb.BuildingInfo());	

							
						}
						else {
							if(i==9 && j==0) {
								rescueSimulation.getCitynformation().setText("*** City Base ***");
								if(this.LastUnit!=null)
									getUnitBurtton(this.LastUnit).setText("");
								this.LastUnit=null;
							}else {
								if(this.LastUnit!=null)
									getUnitBurtton(this.LastUnit).setText("");
								this.LastUnit=null;
								rescueSimulation.getCitynformation().setText("Empty");
							}	
						}	
					}
				}
			}
		}
	}	
	
	public JButton getUnitBurtton(Unit u) {
		int n = emergencyUnits.indexOf(u);
		return unitsbuttons.get(n);
	}
	public ArrayList<Unit> getEmergencyUnits() {
		return emergencyUnits;
	}

	public static void main(String[]args) throws Exception {
		 CommandCenter cc=new CommandCenter();
			

	}

	

}
