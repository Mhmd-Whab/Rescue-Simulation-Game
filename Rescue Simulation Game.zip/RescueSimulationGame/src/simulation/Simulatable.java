package simulation;

import exceptions.UnitException;

public interface Simulatable {
public void cycleStep() throws UnitException;
}
