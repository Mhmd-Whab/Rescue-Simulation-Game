package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.ScrollPane;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.geom.Dimension2D;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import controller.CommandCenter;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import model.units.Ambulance;
import model.units.DiseaseControlUnit;
import model.units.Evacuator;
import model.units.FireTruck;
import model.units.GasControlUnit;
import model.units.Unit;
import simulation.Rescuable;
import simulation.Simulator;

public class RescueSimulation extends JFrame {
    private Rescuable[][] citycontent;
    private JButton[][] citybuttons;
    private JPanel units;
    private JPanel city;
    private JLabel CCycle = new JLabel("Current Cycle :"+0);
    private JLabel Casualties = new JLabel("Number of Casualties : " + 0 );
    private JTextArea Unitinformation = new JTextArea("*** Units Information ***");
    private JTextArea Citynformation = new JTextArea("*** City Information ***");
	private JTextArea log = new JTextArea("                               NEWS" +"\n");
	private int numofCitz=0;
	private JTextArea ActiveDisasters = new JTextArea("*** Active Disasters ***");
	private JButton sound ;
	private Clip clip ;

    
	public RescueSimulation(ActionListener cc) throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		
		setTitle("Rescue Simulation");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setExtendedState(MAXIMIZED_BOTH);
		/*sound
		URL url = this.getClass().getClassLoader().getResource("On-my-wayw.wav");
		AudioInputStream audioIn = AudioSystem.getAudioInputStream(url);
		clip = AudioSystem.getClip();
		clip.open(audioIn);
        clip.start();
        clip.loop(1);*/
        
        
        
		//Center
        
        JPanel center = new JPanel();
        add(center,BorderLayout.CENTER);
        JLabel game = new JLabel("RESCUE SIMULATION GAME");
        game.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 20));
        center.add(game, BorderLayout.NORTH);
		city = new JPanel();
		GridLayout g = new GridLayout(10, 10);
		city.setLayout(g);
		city.setPreferredSize(new Dimension(800, 600));
		center.add(city,BorderLayout.CENTER);
		citybuttons = new JButton[10][10];
		citycontent = new Rescuable[10][10];
		
		for(int i=0;i<10;i++) {
			for(int j=0;j<10;j++) {
				citycontent[i][j]=null;
				citybuttons[i][j] = new JButton();
				citybuttons[i][j].addActionListener(cc);
				city.add(citybuttons[i][j]);
				citybuttons[i][j].setBackground(Color.lightGray);
			}
		}
		ImageIcon Base = new ImageIcon(this.getClass().getResource("/building.png").getFile());
		Image un = Base.getImage().getScaledInstance(70, 60, 100);
		Base = new ImageIcon(un);
		citybuttons[9][0].setIcon(Base);
		JButton q = new JButton("a");
		
		
		//right
		JPanel right = new JPanel(new BorderLayout());
		add(right, BorderLayout.EAST);
		JPanel rightup = new JPanel();
		right.add(rightup,BorderLayout.NORTH);
		units = new JPanel(new GridLayout(4, 1));
		units.setBackground(Color.WHITE);
		units.setPreferredSize(new Dimension(300, 400));
		JScrollPane scrollUnits = new JScrollPane(units);
		rightup.add(scrollUnits, BorderLayout.NORTH);
		rightup.setBackground(Color.BLACK);
		JPanel nx = new JPanel();
		right.add(nx,BorderLayout.SOUTH);
		JButton nextcycle = new JButton("Next Cycle");
		nextcycle.addActionListener(cc);
		nx.add(nextcycle, BorderLayout.NORTH);
		JScrollPane scrollUnitsInfo = new JScrollPane(Unitinformation);
		right.add(scrollUnitsInfo,BorderLayout.CENTER);
		scrollUnitsInfo.setPreferredSize(new Dimension(WIDTH,100));
		Unitinformation.setEditable(false);
		Unitinformation.setBackground(Color.CYAN);
		
		//south
		JPanel south = new JPanel(new BorderLayout());
		add(south,BorderLayout.SOUTH);
		south.setPreferredSize(new Dimension(100, 50));
		JPanel southcenter = new JPanel();
		
		south.add(southcenter, BorderLayout.CENTER);
;		southcenter.add(Casualties, BorderLayout.WEST);
		Casualties.setPreferredSize(new Dimension(500, 20));
		southcenter.add(CCycle, BorderLayout.EAST);
		/*sound = new JButton("");
		ImageIcon audio = new ImageIcon(this.getClass().getResource("/stop.png").getFile());
		Image i = audio.getImage().getScaledInstance(50, 50, 50);
		audio = new ImageIcon(i);
		sound.setIcon(audio);
		sound.setBackground(Color.WHITE);
		sound.addActionListener(cc);
		south.add(sound, BorderLayout.WEST);*/
		
		//left
		JPanel left = new JPanel(new BorderLayout());
		left.setPreferredSize(new Dimension(250, 500));
		add(left, BorderLayout.WEST);
		JPanel leftup = new JPanel(new BorderLayout());
		leftup.setPreferredSize(new Dimension(WIDTH, 200));
		left.add(leftup,BorderLayout.NORTH);
		JPanel leftdown = new JPanel(new BorderLayout());
		leftdown.setPreferredSize(new Dimension(WIDTH, 200));
		left.add(leftdown,BorderLayout.SOUTH);

		
		JScrollPane scrollLog = new JScrollPane(log);
		leftup.add(scrollLog);
		scrollLog.setPreferredSize(new Dimension(WIDTH,200));
		log.setEditable(false);
		log.setBackground(Color.cyan);
		
		JScrollPane scrollDisasters = new JScrollPane(ActiveDisasters);
		left.add(scrollDisasters,BorderLayout.CENTER);
		scrollDisasters.setSize(new Dimension(50, 50));
		ActiveDisasters.setBackground(Color.CYAN);
		
		JScrollPane scrollCityInfo  = new JScrollPane(Citynformation);
		leftdown.add(scrollCityInfo);
		scrollCityInfo.setPreferredSize(new Dimension(500,200));
		Citynformation.setEditable(false);
		Citynformation.setBackground(Color.CYAN);
		
		
	}
	public JTextArea getLog() {
		return log;
	}
	public void AddUnits(ArrayList<JButton> ub, ArrayList<Unit> u ) {
		for(int i=0;i<u.size();i++) {
			units.add(ub.get(i));
			ub.get(i).setBackground(Color.WHITE);
			if(u.get(i) instanceof Ambulance) {
				ImageIcon UnitPhoto = new ImageIcon(this.getClass().getResource("/ambulance.png").getFile());
				Image un = UnitPhoto.getImage().getScaledInstance(100, 100, 100);
				UnitPhoto = new ImageIcon(un);
				ub.get(i).setIcon(UnitPhoto);
			}
			else if(u.get(i) instanceof DiseaseControlUnit) {
				ImageIcon UnitPhoto = new ImageIcon(this.getClass().getResource("/injection.png").getFile());
				Image un = UnitPhoto.getImage().getScaledInstance(100, 100, 100);
				UnitPhoto = new ImageIcon(un);
				ub.get(i).setIcon(UnitPhoto);
			}
			else if (u.get(i) instanceof Evacuator) {
				ImageIcon UnitPhoto = new ImageIcon(this.getClass().getResource("/Police-Car.png").getFile());
				Image un = UnitPhoto.getImage().getScaledInstance(100, 100, 100);
				UnitPhoto = new ImageIcon(un);
				ub.get(i).setIcon(UnitPhoto);
			}
			else if (u.get(i) instanceof FireTruck) {
				ImageIcon UnitPhoto = new ImageIcon(this.getClass().getResource("/Fire-Truck.png").getFile());
				Image un = UnitPhoto.getImage().getScaledInstance(100, 100, 100);
				UnitPhoto = new ImageIcon(un);
				ub.get(i).setIcon(UnitPhoto);
			}
			else if(u.get(i) instanceof GasControlUnit) {
				ImageIcon UnitPhoto = new ImageIcon(this.getClass().getResource("/mask.png").getFile());
				Image un = UnitPhoto.getImage().getScaledInstance(100, 100, 100);
				UnitPhoto = new ImageIcon(un);
				ub.get(i).setIcon(UnitPhoto);
			}
		}
	}
	
	public void AddBuildings(ArrayList<ResidentialBuilding> rb, ActionListener cc) {
		for(int i=0;i<rb.size()&& rb.get(i)!=null;i++) {
			citycontent[9-rb.get(i).getLocation().getY()][rb.get(i).getLocation().getX()]=rb.get(i);
			ImageIcon buildingPhoto = new ImageIcon(this.getClass().getResource("/office-building.png").getFile());
			Image un = buildingPhoto.getImage().getScaledInstance(70, 65, 100);
			buildingPhoto = new ImageIcon(un);
			citybuttons[9-rb.get(i).getLocation().getY()][rb.get(i).getLocation().getX()].setIcon(buildingPhoto);
			
			
			citybuttons[9-rb.get(i).getLocation().getY()][rb.get(i).getLocation().getX()].addActionListener(cc);
			for(int j=0;j<rb.get(i).getOccupants().size();j++) {
				if(rb.get(i).getOccupants().get(j)!=null) {
					numofCitz++;
				}
			}
		}	
	}
	public void AddCitizens(ArrayList<Citizen> c,ActionListener cc) {
		for(int i=0;i<c.size()&& c.get(i)!=null;i++) {
			citycontent[9-c.get(i).getLocation().getY()][c.get(i).getLocation().getX()]=c.get(i);
			ImageIcon CitizenPhoto = new ImageIcon(this.getClass().getResource("/Man-9.png").getFile());
			Image un = CitizenPhoto.getImage().getScaledInstance(100, 100, 100);
			CitizenPhoto = new ImageIcon(un);
			citybuttons[9-c.get(i).getLocation().getY()][c.get(i).getLocation().getX()].setIcon(CitizenPhoto);;
			citybuttons[9-c.get(i).getLocation().getY()][c.get(i).getLocation().getX()].addActionListener(cc);
			for(int j=0;j<c.size();j++) {
				if(c.get(j)!=null) {
					numofCitz++;
				}
			}
		}	
	}
	public JLabel getCCycle() {
		return CCycle;
	}
	public void setCCycle(JLabel cCycle) {
		CCycle = cCycle;
	}
	public JLabel getCasualties() {
		return Casualties;
	}
	public void setCasualties(JLabel casualties) {
		Casualties = casualties;
	}
	public JTextArea getInformation() {
		return Unitinformation;
	}
	public void setInformation(JTextArea Unitinformation) {
		this.Unitinformation = Unitinformation;
	}
	public Rescuable[][] getCitycontent() {
		return citycontent;
	}
	public JButton[][] getCitybuttons() {
		return citybuttons;
	}
	public JTextArea getCitynformation() {
		return Citynformation;
	}
	public int getNumofCitz() {
		return numofCitz;
	}
	public JTextArea getActiveDisasters() {
		return ActiveDisasters;
	}
	public JButton getSound() {
		return sound;
	}
	public Clip getClip() {
		return clip;
	}
	

	

}
